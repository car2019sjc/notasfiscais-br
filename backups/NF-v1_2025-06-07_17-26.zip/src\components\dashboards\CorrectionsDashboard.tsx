import React, { useState, useMemo } from 'react';
import { Download, Filter, X, RefreshCw, Building2, BarChart3 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Card } from '../ui/Card';
import { KPI } from '../ui/KPI';
import { ChartContainer } from '../ui/ChartContainer';
import { CustomTooltip } from '../ui/CustomTooltip';
import { ExecutiveTable } from '../ui/ExecutiveTable';
import { robustParseDate, dateToNumber } from '../../utils/dateUtils';
import { analyzeCorrectionReasons, analyzeCorrectionsByPlant } from '../../utils/dataAnalysis';
import { BRIDGESTONE_COLORS } from '../../constants';
import type { DateFilter } from '../../types';

interface CorrectionsDashboardProps {
  data: any[];
  onExport: (analysis: any) => void;
}

export const CorrectionsDashboard: React.FC<CorrectionsDashboardProps> = ({ data, onExport }) => {
  const [dateFilter, setDateFilter] = useState<DateFilter>({ startDate: '', endDate: '' });

  const filteredData = useMemo(() => {
    const { startDate, endDate } = dateFilter;
    if (!startDate && !endDate) return data;
    
    const startNum = startDate ? parseInt(startDate.replace(/-/g, ''), 10) : null;
    const endNum = endDate ? parseInt(endDate.replace(/-/g, ''), 10) : null;
    
    return data.filter(row => {
      const rowDate = robustParseDate(row['Data']);
      const rowDateNum = dateToNumber(rowDate);
      if (!rowDateNum) return false;
      const isAfterStart = startNum ? rowDateNum >= startNum : true;
      const isBeforeEnd = endNum ? rowDateNum <= endNum : true;
      return isAfterStart && isBeforeEnd;
    });
  }, [data, dateFilter]);

  const analysis = useMemo(() => ({
    total: filteredData.length,
    topReasons: analyzeCorrectionReasons(filteredData),
    byPlant: analyzeCorrectionsByPlant(filteredData),
    activePlants: [...new Set(filteredData.map(r => r['Planta']))].length
  }), [filteredData]);
  
  return (
    <div className="space-y-8 animate-fadeIn">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <h2 className="text-3xl font-bold text-gray-800 bg-gradient-to-r from-amber-600 to-amber-800 bg-clip-text text-transparent">
          Análise de Correções
        </h2>
        <button 
          onClick={() => onExport({
            topCorrectionReasons: analysis.topReasons,
            correctionsByPlant: analysis.byPlant
          })}
          className="bg-gradient-to-r from-green-500 to-green-600 text-white font-bold py-3 px-6 rounded-xl shadow-lg hover:from-green-600 hover:to-green-700 transition-all duration-300 transform hover:scale-105 flex items-center justify-center"
        >
          <Download className="mr-2 h-5 w-5" />
          Exportar Análise
        </button>
      </div>

      <Card>
        <div className="flex items-center gap-2 mb-6">
          <Filter className="w-6 h-6 text-amber-600" />
          <h3 className="text-xl font-bold text-gray-700">Filtros de Data</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
          <div>
            <label htmlFor="startDateCorr" className="block text-sm font-bold text-gray-700 mb-2">
              Data de Início
            </label>
            <input 
              type="date" 
              name="startDate" 
              id="startDateCorr" 
              value={dateFilter.startDate} 
              onChange={(e) => setDateFilter(p => ({...p, startDate: e.target.value}))} 
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-amber-500 focus:ring-amber-500 transition-all duration-300"
            />
          </div>
          <div>
            <label htmlFor="endDateCorr" className="block text-sm font-bold text-gray-700 mb-2">
              Data de Fim
            </label>
            <input 
              type="date" 
              name="endDate" 
              id="endDateCorr" 
              value={dateFilter.endDate} 
              onChange={(e) => setDateFilter(p => ({...p, endDate: e.target.value}))} 
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-amber-500 focus:ring-amber-500 transition-all duration-300"
            />
          </div>
          <div>
            <button 
              onClick={() => setDateFilter({ startDate: '', endDate: ''})} 
              className="w-full bg-gradient-to-r from-gray-500 to-gray-600 text-white font-bold py-3 px-4 rounded-lg hover:from-gray-600 hover:to-gray-700 transition-all duration-300 transform hover:scale-105"
            >
              <X className="inline-block mr-2 h-4 w-4" />
              Limpar Filtros
            </button>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
        <KPI 
          title="Total de Correções" 
          value={analysis.total.toLocaleString('pt-BR')} 
          icon={<RefreshCw className="w-6 h-6" />} 
          color={BRIDGESTONE_COLORS.accent} 
        />
        <KPI 
          title="Plantas Ativas" 
          value={analysis.activePlants.toString()} 
          icon={<Building2 className="w-6 h-6" />} 
          color={BRIDGESTONE_COLORS.success} 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <ExecutiveTable 
          title="Top 10 Motivos de Correção" 
          icon={<BarChart3 className="w-6 h-6" />} 
          data={analysis.topReasons} 
          columns={[
            { header: "Motivo da Correção", accessor: 'motivo' }, 
            { header: "Ocorrências", accessor: 'count' }
          ]} 
        />
        
        <ChartContainer title="Volume de Correções por Planta" icon={<Building2 className="w-6 h-6" />}>
          <ResponsiveContainer>
            <BarChart data={analysis.byPlant}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="value" name="Volume" fill={BRIDGESTONE_COLORS.success} />
            </BarChart>
          </ResponsiveContainer>
        </ChartContainer>
      </div>
    </div>
  );
};