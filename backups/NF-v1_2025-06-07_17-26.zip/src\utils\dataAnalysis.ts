import { robustParseDate, dateToNumber } from './dateUtils';
import type { AnalysisData } from '../types';

export const standardizeErrorMessage = (msg: string): string => {
  if (typeof msg !== 'string' || !msg.trim()) return 'Motivo não especificado';
  
  const rules = [
    { 
      pattern: /tipo de emissãoalterado/i, 
      replacement: "Erro: Alteração do tipo de emissão da NF-e" 
    },
    { 
      pattern: /o valor '.*?' do campo '(.*?)' é inválido/i, 
      replacement: (m: RegExpMatchArray) => `Erro: Valor inválido no campo '${m[1]}'`
    },
    { 
      pattern: /rejeição:\s*(.*)/i, 
      replacement: (m: RegExpMatchArray) => `Rejeição SEFAZ: ${m[1].split('.')[0]}`
    },
    { 
      pattern: /o status da nf-e.*?foi alterado para erro/i, 
      replacement: "Status da NF-e alterado para Erro na SEFAZ"
    },
    { 
      pattern: /<|>/, 
      replacement: 'Erro de formatação (HTML/XML na mensagem)'
    },
    { 
      pattern: /line number|column number/i, 
      replacement: 'Erro de estrutura do arquivo (Linha/Coluna)'
    },
    { 
      pattern: /sefaz/i, 
      replacement: 'Erro de comunicação com a SEFAZ'
    },
  ];
  
  for (const rule of rules) {
    const match = msg.match(rule.pattern);
    if (match) {
      return typeof rule.replacement === 'function' 
        ? rule.replacement(match) 
        : rule.replacement;
    }
  }
  
  return msg.substring(0, 100) + (msg.length > 100 ? '...' : '');
};

export const analyzeCancelationReasons = (data: any[], sefazErrorMap: Map<string, string>): AnalysisData[] => {
  const reasonCounts = data.reduce((acc, row) => {
    let reasonFound = false;
    const statusCode = row['Código status'];
    
    if (statusCode && sefazErrorMap.has(String(statusCode).trim())) {
      let reason = sefazErrorMap.get(String(statusCode).trim()) || '';
      reason = reason.replace(/^rejei[cç][ãa]o:\s*/i, '');
      acc[`Rejeição: ${reason}`] = (acc[`Rejeição: ${reason}`] || 0) + 1;
      reasonFound = true;
    }
    
    if (!reasonFound) {
      const textReasons = [
        row['Motivo para estorno/não utilização'],
        row['Motivo para estorno/não utilização__1'],
        row['Motivo para estorno/não utilização__2'],
        row['Motivo para estorno/não utilização__3'],
        row['Motivo para estorno/não utilização__4'],
      ];
      
      for (const textReason of textReasons) {
        if (textReason && typeof textReason === 'string' && textReason.trim() !== '' && textReason.trim() !== 'N/A') {
          const cleanedReason = standardizeErrorMessage(textReason);
          acc[cleanedReason] = (acc[cleanedReason] || 0) + 1;
          break;
        }
      }
    }
    
    return acc;
  }, {} as Record<string, number>);
  
  return Object.entries(reasonCounts)
    .map(([motivo, count]) => ({ motivo, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);
};

export const analyzeBotVsAnalysts = (data: any[]): AnalysisData[] => {
  const distribution = data.reduce((acc, row) => {
    const modifiedBy = (row['Modificado por'] || '').toUpperCase();
    let category = 'Outros';
    
    if (modifiedBy.includes('NFERPABRAZIL') || modifiedBy.includes('S_RF_DFE') || modifiedBy.includes('RPA')) {
      category = 'Bot (Automação)';
    } else if (modifiedBy.includes('KATIANE') || modifiedBy.includes('CAROLAINE') || modifiedBy.includes('SOUZA')) {
      category = 'Sala de Guerra';
    }
    
    acc[category] = (acc[category] || 0) + 1;
    return acc;
  }, { 'Bot (Automação)': 0, 'Sala de Guerra': 0, 'Outros': 0 } as Record<string, number>);
  
  return Object.entries(distribution).map(([name, value]) => ({ name, value }));
};

export const calculateMonthlyVolume = (data: any[]) => {
  const monthlyData = data.reduce((acc, row) => {
    const date = robustParseDate(row['Data de modificação']);
    if (!date) return acc;
    
    const monthKey = date.toLocaleDateString('pt-BR', { year: '2-digit', month: 'short' });
    
    if (!acc[monthKey]) {
      acc[monthKey] = {
        dateObj: new Date(date.getFullYear(), date.getMonth(), 1),
        mes: monthKey,
        total: 0,
        bot: 0,
        analistas: 0
      };
    }
    
    acc[monthKey].total += 1;
    
    const modifiedBy = (row['Modificado por'] || '').toUpperCase();
    if (modifiedBy.includes('NFERPABRAZIL') || modifiedBy.includes('S_RF_DFE')) {
      acc[monthKey].bot += 1;
    } else {
      acc[monthKey].analistas += 1;
    }
    
    return acc;
  }, {} as Record<string, any>);
  
  return Object.values(monthlyData).sort((a, b) => a.dateObj - b.dateObj);
};

export const analyzeShiftDistribution = (data: any[]): AnalysisData[] => {
  const shiftCounts = data.reduce((acc, row) => {
    const shift = row['Turno'];
    if (shift && ['T1', 'T2', 'T3'].includes(shift)) {
      acc[shift] = (acc[shift] || 0) + 1;
    }
    return acc;
  }, { T1: 0, T2: 0, T3: 0 } as Record<string, number>);
  
  return Object.entries(shiftCounts).map(([name, value]) => ({ name, value }));
};

export const analyzeRejectionsByDayTypeAndShift = (data: any[]) => {
  const result = {
    T1: { 'Semana': 0, 'Fim de Semana': 0 },
    T2: { 'Semana': 0, 'Fim de Semana': 0 },
    T3: { 'Semana': 0, 'Fim de Semana': 0 },
  };
  
  data.forEach(row => {
    const shift = row['Turno'];
    const dayTypeRaw = row['Tipo Semana'];
    
    if (shift && result[shift as keyof typeof result] && dayTypeRaw) {
      const dayType = dayTypeRaw.toLowerCase() === 'week' ? 'Semana' : 'Fim de Semana';
      result[shift as keyof typeof result][dayType] += 1;
    }
  });
  
  return Object.keys(result).map(shift => ({
    name: shift,
    ...result[shift as keyof typeof result]
  }));
};

export const analyzeCorrectionsByPlant = (data: any[]): AnalysisData[] => {
  const plantCounts = data.reduce((acc, row) => {
    const plant = row['Planta'];
    if (plant) {
      acc[plant] = (acc[plant] || 0) + 1;
    }
    return acc;
  }, {} as Record<string, number>);
  
  return Object.entries(plantCounts)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value);
};

export const analyzeCorrectionReasons = (data: any[]): AnalysisData[] => {
  const reasonCounts = data.reduce((acc, row) => {
    const reason = row['Motivo Tax'];
    if (reason) {
      acc[reason] = (acc[reason] || 0) + 1;
    }
    return acc;
  }, {} as Record<string, number>);
  
  return Object.entries(reasonCounts)
    .map(([motivo, count]) => ({ motivo, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);
};