import React from 'react';
import { Card } from './Card';
import type { TableColumn, AnalysisData } from '../../types';

interface ExecutiveTableProps {
  title: string;
  icon: React.ReactNode;
  data: AnalysisData[];
  columns: TableColumn[];
}

export const ExecutiveTable: React.FC<ExecutiveTableProps> = ({ title, icon, data, columns }) => {
  const maxValue = data.length > 0 ? Math.max(...data.map(item => item[columns[1].accessor as keyof AnalysisData] as number)) : 0;
  
  return (
    <Card className="transition-all duration-300 hover:shadow-2xl">
      <div className="flex items-center mb-6">
        <div className="text-red-600 mr-3 p-2 bg-red-50 rounded-lg transition-all duration-300 hover:bg-red-100">
          {icon}
        </div>
        <h3 className="text-xl font-bold text-gray-800">{title}</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gradient-to-r from-gray-50 to-gray-100">
            <tr>
              {columns.map((col, i) => (
                <th 
                  key={i} 
                  scope="col" 
                  className={`px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider ${col.className || ''}`}
                >
                  {col.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-100">
            {data.map((item, i) => (
              <tr key={i} className="hover:bg-gray-50 transition-colors duration-200 group">
                <td className="px-6 py-4 text-sm text-gray-900 max-w-xs break-words font-medium group-hover:text-gray-700">
                  {item[columns[0].accessor as keyof AnalysisData] as string}
                </td>
                <td className="px-6 py-4 text-sm text-gray-500">
                  <div className="flex items-center">
                    <span className="w-16 text-right mr-4 font-bold text-gray-800">
                      {(item[columns[1].accessor as keyof AnalysisData] as number).toLocaleString('pt-BR')}
                    </span>
                    <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                      <div 
                        className="bg-gradient-to-r from-red-500 to-red-600 h-3 rounded-full transition-all duration-500 hover:from-red-600 hover:to-red-700" 
                        style={{ 
                          width: `${((item[columns[1].accessor as keyof AnalysisData] as number) / maxValue) * 100}%` 
                        }}
                      />
                    </div>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
};