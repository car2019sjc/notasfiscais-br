import React, { useState, useMemo } from 'react';
import { Download, Filter, X, FileX, Loader2, BarChart3, PieChart, TrendingUp, CalendarDays } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart as RechartsPieChart, Pie, Cell, ComposedChart, Line } from 'recharts';
import { Card } from '../ui/Card';
import { KPI } from '../ui/KPI';
import { ChartContainer } from '../ui/ChartContainer';
import { CustomTooltip } from '../ui/CustomTooltip';
import { ExecutiveTable } from '../ui/ExecutiveTable';
import { robustParseDate, dateToNumber } from '../../utils/dateUtils';
import { analyzeCancelationReasons, analyzeBotVsAnalysts, calculateMonthlyVolume, analyzeShiftDistribution, analyzeRejectionsByDayTypeAndShift } from '../../utils/dataAnalysis';
import { BRIDGESTONE_COLORS, CHART_COLORS } from '../../constants';
import type { DateFilter } from '../../types';

interface RejectionsDashboardProps {
  data: any[];
  sefazErrorMap: Map<string, string>;
  onExport: (analysis: any) => void;
}

export const RejectionsDashboard: React.FC<RejectionsDashboardProps> = ({ data, sefazErrorMap, onExport }) => {
  const [dateFilter, setDateFilter] = useState<DateFilter>({ startDate: '', endDate: '' });

  const filteredData = useMemo(() => {
    const { startDate, endDate } = dateFilter;
    if (!startDate && !endDate) return data;
    
    const startNum = startDate ? parseInt(startDate.replace(/-/g, ''), 10) : null;
    const endNum = endDate ? parseInt(endDate.replace(/-/g, ''), 10) : null;
    
    return data.filter(row => {
      const rowDateNum = dateToNumber(robustParseDate(row['Data de modificação']));
      if (!rowDateNum) return false;
      const isAfterStart = startNum ? rowDateNum >= startNum : true;
      const isBeforeEnd = endNum ? rowDateNum <= endNum : true;
      return isAfterStart && isBeforeEnd;
    });
  }, [data, dateFilter]);
  
  const analysis = useMemo(() => {
    const botVsAnalysts = analyzeBotVsAnalysts(filteredData);
    const automationRate = botVsAnalysts.reduce((sum, d) => sum + d.value, 0) > 0 
      ? ((botVsAnalysts.find(d => d.name === 'Bot (Automação)')?.value || 0) / botVsAnalysts.reduce((sum, d) => sum + d.value, 0)) * 100 
      : 0;
    
    return {
      total: filteredData.length,
      topReasons: analyzeCancelationReasons(filteredData, sefazErrorMap),
      botVsAnalysts,
      automationRate,
      monthlyVolume: calculateMonthlyVolume(filteredData),
      shiftDistribution: analyzeShiftDistribution(filteredData),
      rejectionsByDayTypeAndShift: analyzeRejectionsByDayTypeAndShift(filteredData)
    };
  }, [filteredData, sefazErrorMap]);
  
  return (
    <div className="space-y-8 animate-fadeIn">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <h2 className="text-3xl font-bold text-gray-800 bg-gradient-to-r from-red-600 to-red-800 bg-clip-text text-transparent">
          Análise de Rejeições
        </h2>
        <button 
          onClick={() => onExport({
            topCancelReasons: analysis.topReasons,
            botVsAnalysts: analysis.botVsAnalysts,
            monthlyVolume: analysis.monthlyVolume,
            shiftDistribution: analysis.shiftDistribution,
            rejectionsByDayTypeAndShift: analysis.rejectionsByDayTypeAndShift
          })}
          className="bg-gradient-to-r from-green-500 to-green-600 text-white font-bold py-3 px-6 rounded-xl shadow-lg hover:from-green-600 hover:to-green-700 transition-all duration-300 transform hover:scale-105 flex items-center justify-center"
        >
          <Download className="mr-2 h-5 w-5" />
          Exportar Análise
        </button>
      </div>

      <Card>
        <div className="flex items-center gap-2 mb-6">
          <Filter className="w-6 h-6 text-red-600" />
          <h3 className="text-xl font-bold text-gray-700">Filtros de Data</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
          <div>
            <label htmlFor="startDateRej" className="block text-sm font-bold text-gray-700 mb-2">
              Data de Início
            </label>
            <input 
              type="date" 
              name="startDate" 
              id="startDateRej" 
              value={dateFilter.startDate} 
              onChange={(e) => setDateFilter(p => ({...p, startDate: e.target.value}))} 
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 transition-all duration-300"
            />
          </div>
          <div>
            <label htmlFor="endDateRej" className="block text-sm font-bold text-gray-700 mb-2">
              Data de Fim
            </label>
            <input 
              type="date" 
              name="endDate" 
              id="endDateRej" 
              value={dateFilter.endDate} 
              onChange={(e) => setDateFilter(p => ({...p, endDate: e.target.value}))} 
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 transition-all duration-300"
            />
          </div>
          <div>
            <button 
              onClick={() => setDateFilter({ startDate: '', endDate: ''})} 
              className="w-full bg-gradient-to-r from-gray-500 to-gray-600 text-white font-bold py-3 px-4 rounded-lg hover:from-gray-600 hover:to-gray-700 transition-all duration-300 transform hover:scale-105"
            >
              <X className="inline-block mr-2 h-4 w-4" />
              Limpar Filtros
            </button>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
        <KPI 
          title="Total de Cancelamentos" 
          value={analysis.total.toLocaleString('pt-BR')} 
          icon={<FileX className="w-6 h-6" />} 
          color={BRIDGESTONE_COLORS.primary} 
        />
        <KPI 
          title="Taxa de Automação" 
          value={`${analysis.automationRate.toFixed(1)}%`} 
          icon={<Loader2 className="w-6 h-6" />} 
          color={BRIDGESTONE_COLORS.info} 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <ExecutiveTable 
          title="Top 10 Motivos de Cancelamento" 
          icon={<BarChart3 className="w-6 h-6" />} 
          data={analysis.topReasons} 
          columns={[
            { header: "Motivo Padronizado", accessor: 'motivo' }, 
            { header: "Ocorrências", accessor: 'count' }
          ]} 
        />
        
        <ChartContainer title="Bot vs. Sala de Guerra" icon={<PieChart className="w-6 h-6" />}>
          <ResponsiveContainer>
            <RechartsPieChart>
              <Pie 
                data={analysis.botVsAnalysts} 
                dataKey="value" 
                nameKey="name" 
                cx="50%" 
                cy="50%" 
                outerRadius={120} 
                labelLine={false} 
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {analysis.botVsAnalysts.map((entry, i) => (
                  <Cell key={`cell-${i}`} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
              <Legend />
            </RechartsPieChart>
          </ResponsiveContainer>
        </ChartContainer>

        <ChartContainer title="Volume Mensal" icon={<TrendingUp className="w-6 h-6" />}>
          <ResponsiveContainer>
            <ComposedChart data={analysis.monthlyVolume}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="mes" />
              <YAxis />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Bar dataKey="bot" stackId="a" fill={BRIDGESTONE_COLORS.info} name="Bot" />
              <Bar dataKey="analistas" stackId="a" fill={BRIDGESTONE_COLORS.accent} name="Analistas" />
              <Line type="monotone" dataKey="total" stroke={BRIDGESTONE_COLORS.primary} strokeWidth={3} name="Total" />
            </ComposedChart>
          </ResponsiveContainer>
        </ChartContainer>

        <ChartContainer title="Distribuição por Turno" icon={<BarChart3 className="w-6 h-6" />}>
          <ResponsiveContainer>
            <BarChart data={analysis.shiftDistribution}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="value" name="Volume" fill={BRIDGESTONE_COLORS.secondary} />
            </BarChart>
          </ResponsiveContainer>
        </ChartContainer>

        <ChartContainer title="Rejeições por Período e Turno" icon={<CalendarDays className="w-6 h-6" />}>
          <ResponsiveContainer>
            <BarChart data={analysis.rejectionsByDayTypeAndShift}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Bar dataKey="Semana" fill={BRIDGESTONE_COLORS.info} name="Semana" />
              <Bar dataKey="Fim de Semana" fill={BRIDGESTONE_COLORS.accent} name="Fim de Semana" />
            </BarChart>
          </ResponsiveContainer>
        </ChartContainer>
      </div>
    </div>
  );
};