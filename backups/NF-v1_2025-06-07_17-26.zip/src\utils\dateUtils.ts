export const robustParseDate = (value: any): Date | null => {
  if (!value) return null;
  
  if (value instanceof Date && !isNaN(value.getTime())) {
    return value;
  }
  
  if (typeof value === 'number') {
    // Excel serial date
    const excelDate = new Date((value - 25569) * 86400 * 1000);
    const date = new Date(excelDate.getTime() + (excelDate.getTimezoneOffset() * 60000));
    return date;
  }
  
  if (typeof value === 'string') {
    // DD/MM/YYYY format
    const partsDDMMYYYY = value.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})/);
    if (partsDDMMYYYY) {
      const date = new Date(parseInt(partsDDMMYYYY[3]), parseInt(partsDDMMYYYY[2]) - 1, parseInt(partsDDMMYYYY[1]));
      return date;
    }
    
    // M-YYYY format
    const partsMYYYY = value.match(/^(\d{1,2})-(\d{4})$/);
    if (partsMYYYY) {
      const date = new Date(parseInt(partsMYYYY[2]), parseInt(partsMYYYY[1]) - 1, 1);
      return date;
    }
    
    // ISO format
    const isoDate = new Date(value);
    if (!isNaN(isoDate.getTime())) {
      const date = new Date(isoDate.getTime() + (isoDate.getTimezoneOffset() * 60000));
      return date;
    }
  }
  
  return null;
};

export const dateToNumber = (date: Date | null): number | null => {
  if (!date) return null;
  return parseInt(
    `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, '0')}${String(date.getDate()).padStart(2, '0')}`,
    10
  );
};